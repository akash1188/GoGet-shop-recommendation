

1. Plugins used:
  a. flutter_spinkit: collection of loading indicators 
  b. google_fonts: helper to import fonts from fonts.google.com
  c. geolocator: get user lat, long coordinates
  d. geocoding: get user address using coordinates from geolocator
  e. firebase_core: Top-most firebase plugin 
  f. firebase_auth: plugin to enable firebase authentication services
  g. cloud_firestore: plugin to connect with firebase firestore DB
